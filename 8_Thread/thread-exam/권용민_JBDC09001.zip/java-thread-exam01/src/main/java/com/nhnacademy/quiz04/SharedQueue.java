package com.nhnacademy.quiz04;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.TimeoutException;

public class SharedQueue {
    // TODO: 필드를 선언하세요.
    List<Integer> sharedQueue;
    private final int maxSize;

    public SharedQueue(int maxSize) {
        // TODO: 인수 검증과 필드 초기화를 하세요.
        this.maxSize = maxSize;
        sharedQueue = Collections.synchronizedList(new LinkedList<>());
    }

    public synchronized void enqueue(int value) {
        // TODO: 요구 기능을 구현하세요.
        if(value < 0) {
            throw new IllegalArgumentException();
        }

        while(sharedQueue.size() >= maxSize) {
            try {
                wait();
            } catch (InterruptedException e) {
                throw new RuntimeException();
            }
        }

        sharedQueue.add(value);
        notifyAll();
    }

    public synchronized void enqueue(int value, long timeout) throws TimeoutException {
        // TODO: 요구 기능을 구현하세요.
        if(value < 0 || timeout < 0) {
            throw new IllegalArgumentException();
        }

        while(sharedQueue.size() >= maxSize) {
            try {
                wait(timeout);
            } catch (Exception e) {
                throw new TimeoutException();
            }
        }

        sharedQueue.add(value);
        notifyAll();
    }

    public synchronized int dequeue() {
        // TODO: 요구 기능을 구현하세요.
        while(sharedQueue.isEmpty()) {
            try {
                wait();
            } catch (InterruptedException e) {
                throw new RuntimeException();
            }
        }

        notifyAll();
        return sharedQueue.removeFirst();
    }

    public synchronized int dequeue(long timeout) throws TimeoutException {
        // TODO: 요구 기능을 구현하세요.
        while(sharedQueue.isEmpty()) {
            try {
                wait(timeout);
            } catch (Exception e) {
                throw new TimeoutException();
                //Thread.currentThread().interrupt();
            }
        }

        int first = sharedQueue.getFirst();
        sharedQueue.removeFirst();
        notifyAll();
        return first;
    }

    public synchronized int size() {
        // TODO: 요구 기능을 구현하세요.
        return sharedQueue.size();
    }
}
