public class Sample {
    int I = 5;
}